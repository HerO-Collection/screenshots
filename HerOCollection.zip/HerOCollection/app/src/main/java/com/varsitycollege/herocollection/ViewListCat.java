package com.varsitycollege.herocollection;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.ArrayList;
import java.util.List;

public class ViewListCat extends AppCompatActivity
{

    private ListView lstvOrderHistory;
    private List<String> orderList;
    private ArrayAdapter<String> orderAdapter;
    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference heroCollec = database.getReference("categories");
    private Button logOutCat;
    private Button CatDone;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_list_cat);
        orderList = new ArrayList<>();
        lstvOrderHistory = findViewById(R.id.lstv_OrderHistory);
        ActionBar actionBar = getSupportActionBar();

        actionBar.setDisplayHomeAsUpEnabled(true);

        logOutCat = findViewById(R.id.btn_logout_view_cat);
        CatDone = findViewById(R.id.btn_view_list_done_cat);

        logOutCat.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(ViewListCat.this, MainActivity.class);
                startActivity(intent);
            }
        });
        heroCollec.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot pulledOrder : snapshot.getChildren()) {
                    Category category = pulledOrder.getValue(Category.class);
                    orderList.add(category.toString());
                }
                orderAdapter = new ArrayAdapter<String>(ViewListCat.this,
                        android.R.layout.simple_list_item_1, orderList);
                lstvOrderHistory.setAdapter(orderAdapter);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error){
                Toast.makeText(ViewListCat.this,
                        "Error Reading from Database", Toast.LENGTH_SHORT).show();
            }
        });
        CatDone.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(ViewListCat.this, ViewList.class);
                startActivity(intent);
            }
        });
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        switch (item.getItemId()){
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}