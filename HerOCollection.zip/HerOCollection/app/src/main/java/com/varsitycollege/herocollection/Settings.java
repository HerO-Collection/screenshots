package com.varsitycollege.herocollection;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class Settings extends AppCompatActivity
{
        private ImageButton settings;
        private Button logoutOfSettings;
        private TextView goals, graph, data, dis;

        @Override
        protected void onCreate(Bundle savedInstanceState)
        {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_settings);

            ActionBar actionBar = getSupportActionBar();

            actionBar.setDisplayHomeAsUpEnabled(true);

            //settings = findViewById(R.id.settingsButtonMenus);
            logoutOfSettings = findViewById(R.id.logout_settings);

            logoutOfSettings.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    Intent i = new Intent(Settings.this, LogOut.class);

                    startActivity(i);
                }
            });

            goals = findViewById(R.id.tv_addGoals);
            graph = findViewById(R.id.tv_graph);
            dis = findViewById(R.id.tv_display);
            data = findViewById(R.id.tv_database);

            goals.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    Intent i = new Intent(Settings.this, CreateCategory.class);

                    startActivity(i);
                }
            });

            graph.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    //Dispaly the items graph
                }
            });

            dis.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    //Display the category goals.
                }
            });

            data.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    Intent i = new Intent(Settings.this, ViewList.class);

                    startActivity(i);
                }
            });

        /*settings.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent i = new Intent(Settings.this, LogOut.class);

                startActivity(i);
            }
        });*/
        }

        public boolean onOptionsItemSelected(@NonNull MenuItem item)
        {

            switch (item.getItemId())
            {
                case android.R.id.home:
                    this.finish();
                    return true;

            }
            return super.onOptionsItemSelected(item);
        }
}